#ifndef __foo_h__
#define __foo_h__
 
extern void foo(void);
 
#endif  // __foo_h__
