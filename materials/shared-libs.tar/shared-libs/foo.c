#include <stdio.h>

void foo(void){
    printf("Hello, I am a shared library\n");
}
